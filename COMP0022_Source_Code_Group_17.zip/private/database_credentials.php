<?php

// freeBay database credentials
define('host', 'localhost');
define('username', "admin");
define('password', "adminpassword");
define('database', "Freebay");

?>